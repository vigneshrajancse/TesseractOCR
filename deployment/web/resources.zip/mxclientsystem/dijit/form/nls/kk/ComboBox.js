//>>built
define("dijit/form/nls/kk/ComboBox",({previousMessage:"Алдыңғы нұсқалар",nextMessage:"Басқа нұсқалар"}));
